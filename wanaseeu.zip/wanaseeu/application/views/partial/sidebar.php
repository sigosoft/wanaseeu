<div class="left side-menu">
                <div class="slimscroll-menu" id="remove-scroll">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metismenu" id="side-menu">
                            <li class="menu-title">Navigation</li>
                            <li>
                                <a href="<?=site_url('Login/show')?>">
                                    <i class="fa fa-home"></i><span> Home </span>
                                </a>
                            </li>

                            <li>
                                <a href="#"><i class="fa fa-address-book-o"></i> <span> Brand </span> <span class="menu-arrow"></span></a>
                                <ul class="nav-second-level" aria-expanded="false">
                                    <li><a href="<?=site_url('Brand/index')?>"medical-records.html">Add Brand</a></li>
                                    <li><a href="<?=site_url('Brand/show')?>">Manage Brand</a></li>
                                </ul>
                            </li>
							<li>
                                <a href="#"><i class="fa fa-address-book-o"></i> <span> Product </span> <span class="menu-arrow"></span></a>
                                <ul class="nav-second-level" aria-expanded="false">
                                    <li><a href="<?=site_url('Product/index')?>"medical-records.html">Add Product</a></li>
                                    <li><a href="<?=site_url('Product/show')?>">Manage Product</a></li>
                                </ul>
                            </li>
						<!--	<li>
                                <a href="consult-now.html">
                                    <i class="fa fa-user-md"></i><span> Consult Now </span>
                                </a>
                            </li>-->
							
							
                        </ul>

                    </div>
                    <!-- Sidebar -->
                    <div class="clearfix"></div>

                </div>
                <!-- Sidebar -left -->

     </div>       