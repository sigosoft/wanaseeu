<?php
 
 class Group_api extends CI_Controller {

 	public function __construct()
 	{
 		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Groupapi_model');

 	}
 	public function group()
 	{
 	    
 	 $group_name=$_POST['group_name'];
 	 //$group_description=$_POST['group_description'];
 	 $group_creator=$_POST['group_creator'];
 	 $group_image=$_POST['group_image'];
 	 
 	 	$url =  FCPATH.'upload/';
				$rand=date('Ymd').mt_rand(1001,9999);
				$userpath = $url.$rand.'.png';
				$path = "upload/".$rand.'.png';
				file_put_contents($userpath,base64_decode($group_image));
 	 
 	 $array=[
 	     'group_name'=>$group_name,
 	    // 'group_description'=>$group_description,
 	      'group_creator'=>$group_creator,
 	      'group_image' =>$group_image
 	     ];
 	     
 	 
     $group=$this->Groupapi_model->group($array);
    
     $return=[
      'message'=>'success',
      
      
     ];
    print_r(json_encode($return));
 	}
 	
 	
 	public function group_data()
 	{
 	    
     $group_data=$this->Groupapi_model->group_data();
    
     $return=[
      'message'=>'success',
      'data'=>$group_data
      
     ];
    print_r(json_encode($return));
 	}
 	
 	public function databyid()
 	{
 	   $grp_id=$_POST['group_id'];
    

     $data=$this->Groupapi_model->databyid($grp_id);

     $return=[
      'message'=>'success',
      'data'=>$data
     ];
    print_r(json_encode($return));
 	}
 }
?>