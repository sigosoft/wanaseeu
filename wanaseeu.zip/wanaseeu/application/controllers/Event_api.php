<?php
 
 class Event_api extends CI_Controller {

 	public function __construct()
 	{
 		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Eventapi_model');

 	}
 	public function create_event()
 	{
 	    
 	 $event_name=$_POST['event_name'];
 	 $event_date=$_POST['event_date'];
 	 $event_time=$_POST['event_time'];
 	 $event_location=$_POST['event_location'];
 	 $event_address=$_POST['event_address'];
 	 $event_description=$_POST['event_description'];
 	 $array=[
 	     'event_name'=>$event_name,
 	   
 	      'event_date'=>$event_date,
 	      'event_time'=>$event_time,
 	      'event_location'=>$event_location,
 	      'event_address' =>$event_address,
 	      'event_description'=>$event_description
 	     ];
 	     
 	 
     $group=$this->Eventapi_model->create_event($array);
    
     $return=[
      'message'=>'success',
      
      
     ];
    print_r(json_encode($return));
 	}
 	
 	
/* 	public function group_data()
 	{
 	    
     $group_data=$this->Groupapi_model->group_data();
    
     $return=[
      'message'=>'success',
      'data'=>$group_data
      
     ];
    print_r(json_encode($return));
 	}
 	
 	public function databyid()
 	{
 	   $grp_id=$_POST['group_id'];
    

     $data=$this->Groupapi_model->databyid($grp_id);

     $return=[
      'message'=>'success',
      'data'=>$data
     ];
    print_r(json_encode($return));
 	}*/
 }
?>