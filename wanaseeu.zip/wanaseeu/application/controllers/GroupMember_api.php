<?php
 
 class GroupMember_api extends CI_Controller {

 	public function __construct()
 	{
 		parent::__construct();
		$this->load->helper('url');
		$this->load->model('GroupMemberapi_model');

 	}
 	public function add_groupmember()
 	{
 	    
 	 $group_id=$_POST['group_id'];
 	 $member_id=$_POST['member_id'];
 	 
 	 $array=[
 	     'group_id'=>$group_id,
 	     'member_id'=>$member_id
 	      
 	     ];
 	     
 	 
     $group=$this->GroupMemberapi_model->add_groupmember($array);
    
     $return=[
      'message'=>'success',
      
      
     ];
    print_r(json_encode($return));
 	}
 	
 	
	public function getmemberby_group()
 	{
 	  
 	  $grp_id=$_POST['group_id'];
 	    
     $member=$this->GroupMemberapi_model->getmemberby_group($grp_id);
    
     $return=[
      'message'=>'success',
      'data'=>$member
      
     ];
    print_r(json_encode($return));
 	}
 	
  /*	public function databyid()
 	{
 	   $grp_id=$_POST['group_id'];
    

     $data=$this->Groupapi_model->databyid($grp_id);

     $return=[
      'message'=>'success',
      'data'=>$data
     ];
    print_r(json_encode($return));
 	}
 	*/
 }
?>