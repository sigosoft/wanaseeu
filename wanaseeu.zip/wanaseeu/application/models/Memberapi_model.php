<?php

class Memberapi_model extends CI_Model {

	public function _construct()
	{
		parent:: _contruct();
		$this->load->database();

	}

	
	
	public function getmember()
	{
		$this->db->select('member_id,name,phone,image');
		$this->db->from('member');
		
		return $this->db->get()->result();

		
	}

}



?>