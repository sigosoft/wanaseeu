<?php

class Groupapi_model extends CI_Model {

	public function _construct()
	{
		parent:: _contruct();
		$this->load->database();

	}

	
	
	public function group($array)
	{
		$this->db->insert('groups',$array);

	}
	
	public function group_data()
	{
	   
	   $this->db->select('group_id,group_name,group_creator,group_image');
		$this->db->from('groups');
		return $this->db->get()->result();
	}
	
	public function databyid($grp_id)
	{
	    
		$this->db->select('groups.group_id,groups.group_name,groups.group_image,member.member_id,member.name');
		$this->db->from('groups');
		$this->db->join('member', 'groups.group_creator = member.member_id', 'inner');
    	$this->db->where('groups.group_id',$grp_id);
//$this->db->where('group_id',$grp_id);
		return $this->db->get()->result();

	}

}



?>