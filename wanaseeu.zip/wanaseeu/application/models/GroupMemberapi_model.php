<?php

class GroupMemberapi_model extends CI_Model {

	public function _construct()
	{
		parent:: _contruct();
		$this->load->database();

	}

	
	
	public function add_groupmember($array)
	{
		$this->db->insert('group_members',$array);

	}
	
	public function getmemberby_group($grp_id)
	{
	   
	   $this->db->select('group_members.group_id,group_members.member_id');
		$this->db->from('group_members');
		$this->db->join('member', 'group_members.member_id = member.member_id', 'inner');
		$this->db->where('group_members.group_id',$grp_id);
		return $this->db->get()->result();
		
	}
	
/*	public function databyid($grp_id)
	{
	    
		$this->db->select('groups.group_id,groups.group_name,groups.group_image,member.member_id,member.name');
		$this->db->from('groups');
		$this->db->join('member', 'groups.group_creator = member.member_id', 'inner');
    	$this->db->where('groups.group_id',$grp_id);
//$this->db->where('group_id',$grp_id);
		return $this->db->get()->result();

	}
*/
}



?>